package pruebaFirebase;



public class Principal {
	
	static Control app;
	
	public static void main(String[] args){
		app = new Control();
		app.start();		
	}

}
